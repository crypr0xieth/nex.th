import React from 'react'

export function Connect() {
  return (
    <div>
      <w3m-button label='Connect' balance='hide' size='sm' />
    </div>
  )
}
